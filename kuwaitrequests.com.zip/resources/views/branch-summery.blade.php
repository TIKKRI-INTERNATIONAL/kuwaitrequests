@include('header')

<!-- <section> close ============================--><!-- ============================================-->

<section class="py-0 bg-dark bottom-bar" data-bs-theme="light">
    <div>
        <hr class="my-0 text-600 opacity-25">
        <div class="container py-3">
            <div class="row justify-content-between fs-10">
                <div class="col-12 col-sm-auto text-center">
                    <p class="mb-0 text-600 opacity-85">All Rights Reserved. <span class="d-none d-sm-inline-block">|
                        </span><br class="d-sm-none"> 2024
                        &copy; <a class="text-white opacity-85" href="#">Delivery Solution
                            Portal</a></p>
                </div>

            </div>
        </div>
    </div><!-- end of .container-->
</section>
</div>

</div>

</div>
</main>
<!-- ===============================================--><!--    End of Main Content--><!-- ===============================================-->


<!-- ===============================================--><!--    JavaScripts--><!-- ===============================================-->
@include('footer')
